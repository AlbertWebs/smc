<footer id="footer" class="mt-0">
    <div class="footer-copyright">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col d-flex align-items-center justify-content-center">
                    <ul class="footer-social-icons social-icons social-icons-clean social-icons-icon-light mb-3">
                        <li class="social-icons-facebook"><a href="https://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook-f text-2"></i></a></li>
                        <li class="social-icons-twitter"><a href="https://www.twitter.com/" target="_blank" title="Twitter"><i class="fab fa-twitter text-2"></i></a></li>
                        <li class="social-icons-linkedin"><a href="https://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in text-2"></i></a></li>
                    </ul>
                    <p> Copyright © 2021 <strong>Sasema Management Company</strong> All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>